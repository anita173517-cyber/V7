package com.harindra.tvlauncher

import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView

object Animation4D {

    private val springOvershoot = OvershootInterpolator(1.35f)
    private val smoothDecel = DecelerateInterpolator(1.6f)
    private val kenBurnsInterp = AccelerateDecelerateInterpolator()

    fun apply4dFocus(view: View, hasFocus: Boolean, ultraLite: Boolean, scaleTarget: Float = 1.11f) {
        if (ultraLite) {
            view.scaleX = if (hasFocus) 1.04f else 1.0f
            view.scaleY = if (hasFocus) 1.04f else 1.0f
            view.elevation = if (hasFocus) 10f else 2f
            return
        }

        val density = view.resources.displayMetrics.density
        view.cameraDistance = 6000f * density
        view.animate().cancel()

        if (hasFocus) {
            view.elevation = 22f
            view.translationZ = 14f
            // 4D lively entrance pulse: slight 3D perspective tilt that springs into crisp forward lift
            view.rotationY = -4.0f
            view.rotationX = 2.0f
            view.animate()
                .scaleX(scaleTarget)
                .scaleY(scaleTarget)
                .rotationY(0f)
                .rotationX(0f)
                .translationY(-4f)
                .setDuration(230L)
                .setInterpolator(springOvershoot)
                .start()
        } else {
            view.elevation = 4f
            view.translationZ = 0f
            view.animate()
                .scaleX(1.0f)
                .scaleY(1.0f)
                .rotationY(0f)
                .rotationX(0f)
                .translationY(0f)
                .setDuration(170L)
                .setInterpolator(smoothDecel)
                .start()
        }
    }

    fun animateKenBurnsHero(imageView: ImageView, enable4d: Boolean) {
        imageView.animate().cancel()
        imageView.alpha = 0.25f
        imageView.scaleX = 1.0f
        imageView.scaleY = 1.0f
        imageView.animate()
            .alpha(1.0f)
            .setDuration(420L)
            .setInterpolator(smoothDecel)
            .withEndAction {
                if (enable4d) {
                    imageView.animate()
                        .scaleX(1.08f)
                        .scaleY(1.08f)
                        .setDuration(8500L)
                        .setInterpolator(kenBurnsInterp)
                        .start()
                }
            }
            .start()
    }

    fun animateTabEntrance(view: View, ultraLite: Boolean) {
        if (ultraLite) return
        view.animate().cancel()
        view.alpha = 0f
        view.translationY = 18f
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(240L)
            .setInterpolator(smoothDecel)
            .start()
    }
}
