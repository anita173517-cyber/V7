package com.harindra.tvlauncher

data class AppItem(
    val packageName: String,
    val label: String,
    val isTvApp: Boolean,
    val isLiveTvCandidate: Boolean
)

data class LiveChannel(
    val id: String,
    val name: String,
    val group: String,
    val logoUrl: String,
    val streamUrl: String,
    val userAgent: String = "",
    val referrer: String = ""
)

data class YouTubeVideo(
    val videoId: String,
    val title: String,
    val channelName: String,
    val category: String = "Trending",
    val badge: String = "4K",
    val fallbackResId: Int = R.drawable.hero_action_4k,
    val watchedAtMs: Long = 0L
) {
    val thumbUrl: String
        get() = if (videoId.isNotBlank()) "https://i.ytimg.com/vi/$videoId/hqdefault.jpg" else ""
}

data class ContinueWatchingItem(
    val id: String,
    val type: Int,
    val title: String,
    val subtitle: String,
    val sourceLabel: String,
    val thumbUrl: String,
    val fallbackResId: Int,
    val progressPercent: Int,
    val timestampMs: Long,
    val videoId: String = "",
    val streamUrl: String = "",
    val streamUserAgent: String = "",
    val streamReferrer: String = "",
    val packageName: String = "",
    val deepLinkUri: String = ""
) {
    companion object {
        const val TYPE_YOUTUBE = 1
        const val TYPE_IPTV_CHANNEL = 2
        const val TYPE_IPTV_APP = 3
        const val TYPE_WATCH_NEXT = 4
        const val TYPE_YOUTUBE_SEARCH = 5
    }
}

data class HeroSlide(
    val badge: String,
    val title: String,
    val subtitle: String,
    val ctaText: String,
    val backdropResId: Int,
    val backdropUrl: String = "",
    val actionType: Int = ACTION_OPEN_APP,
    val targetId: String = ""
) {
    companion object {
        const val ACTION_RESUME_IPTV = 1
        const val ACTION_RESUME_YOUTUBE = 2
        const val ACTION_OPEN_APP = 3
        const val ACTION_OPEN_LIVE_TAB = 4
        const val ACTION_BOOST_RAM = 5
    }
}
