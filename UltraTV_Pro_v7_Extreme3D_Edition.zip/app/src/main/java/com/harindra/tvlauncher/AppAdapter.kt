package com.harindra.tvlauncher

import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val pm: PackageManager,
    private val prefs: PrefsManager,
    private val onAppClick: (AppItem) -> Unit,
    private val onAppLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    private val items = mutableListOf<AppItem>()

    fun submitList(newItems: List<AppItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_card, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    private fun brandColorsFor(pkg: String, label: String): IntArray {
        val key = (pkg + " " + label).lowercase()
        return when {
            key.contains("harindra") || key.contains("ram player") || key.contains("iptv") ->
                intArrayOf(Color.parseColor("#0284C7"), Color.parseColor("#4F46E5"))
            key.contains("youtube") || key.contains("smarttube") ->
                intArrayOf(Color.parseColor("#DC2626"), Color.parseColor("#7F1D1D"))
            key.contains("netflix") ->
                intArrayOf(Color.parseColor("#B91C1C"), Color.parseColor("#18181B"))
            key.contains("amazon") || key.contains("prime") ->
                intArrayOf(Color.parseColor("#0EA5E9"), Color.parseColor("#1D4ED8"))
            key.contains("hotstar") || key.contains("disney") ->
                intArrayOf(Color.parseColor("#1E3A8A"), Color.parseColor("#0F172A"))
            key.contains("zee5") ->
                intArrayOf(Color.parseColor("#7E22CE"), Color.parseColor("#3B0764"))
            key.contains("sonyliv") || key.contains("sony") ->
                intArrayOf(Color.parseColor("#312E81"), Color.parseColor("#7C3AED"))
            key.contains("jio") ->
                intArrayOf(Color.parseColor("#DB2777"), Color.parseColor("#701A75"))
            key.contains("mxtech") || key.contains("mxplayer") ->
                intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#0369A1"))
            key.contains("vlc") ->
                intArrayOf(Color.parseColor("#EA580C"), Color.parseColor("#7C2D12"))
            else ->
                intArrayOf(Color.parseColor("#1E293B"), Color.parseColor("#0F172A"))
        }
    }

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val innerBox: LinearLayout = itemView.findViewById(R.id.appCardInner)
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvBadgeTop: TextView = itemView.findViewById(R.id.tvBadgeTop)

        fun bind(item: AppItem) {
            tvName.text = item.label
            MediaImageLoader.loadAppIcon(pm, item.packageName, ivIcon)

            val grad = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                brandColorsFor(item.packageName, item.label)
            ).apply {
                cornerRadius = 12f * itemView.resources.displayMetrics.density
            }
            innerBox.background = grad

            val speedDigit = prefs.findSpeedDialDigit("app:${item.packageName}")
            val isLocked = item.packageName in prefs.getLockedPackages()
            when {
                isLocked && speedDigit != null -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "🔒 #$speedDigit"
                }
                isLocked -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "🔒"
                }
                speedDigit != null -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "#$speedDigit"
                }
                else -> tvBadgeTop.visibility = View.GONE
            }

            itemView.setOnClickListener { onAppClick(item) }
            itemView.setOnLongClickListener {
                onAppLongClick(item)
                true
            }
            itemView.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_MENU) {
                    onAppLongClick(item)
                    true
                } else false
            }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.12f)
            }
        }
    }
}
